(function () {
    'use strict';
    PatientFileApp.factory('userInfo', userInfo);
    function userInfo($http) {
        // get pe ruta laravel
        var userInfo = $http.get('/patient/profile');

        return {
            get: function () {
                return userInfo;
            }
        }
    }
})();