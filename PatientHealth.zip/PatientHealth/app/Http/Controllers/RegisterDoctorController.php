<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Doctor;
use App\Clinic;
use Response;

class RegisterDoctorController extends Controller
{
    public function index(){

        $clinics = Clinic::get();

        return Response::json($clinics);
    }

    public function store()
    {
        $this->validate(request(), [
            'name' => 'required',
            'specialization' => 'required',
            'clinic' => 'required',
            'email' => 'required|unique:patients',
            'password' => 'required|min:6',
        ]);

        Doctor::create([
            'name' => request('name'),
            'email' => request('email'),
            'specialization' => request('specialization'),
            'clinic_id' => request('clinic'),
            'password'=>bcrypt(request('password'))
        ]);

        return Response::json(array('success' => true));
    }
}

