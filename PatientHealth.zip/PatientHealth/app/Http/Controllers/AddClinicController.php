<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Clinic;

class AddClinicController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['clinics']);
    }
    public function index(){

        return view('/clinics/add');
    }

    public function store()
    {
        $this->validate(request(), [
            'name' => 'required',
            'address' => 'required',
        ]);

        Clinic::create([
            'name' => request('name'),
            'address' => request('address')
        ]);


        //and then redirect to the home page

        return redirect('/clinics/clinics');
    }

}
