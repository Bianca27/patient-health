(function () {
    'use strict';
    PatientFileApp.controller('AddUserPatientController', AddUserPatientController);
    function AddUserPatientController($http, $location, $mdDialog) {
        var vm = this;
        vm.addUser = function (user, ev) {

            var data = {
                firstname: vm.firstname,
                lastname: vm.lastname,
                cnp: vm.cnp,
                email: vm.email,
                password: vm.password
            };
            $http.post('patient/register', data)
                .then(function onSuccess(response){
                    var data = response.data;
                    var status = response.status;

                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('Felicitari!')
                            .textContent('Contul tau a fost creat cu succes!')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('OK!')
                            .targetEvent(ev)
                    ).then(function() {
                        $location.path('/login');
                    });
                }).catch(function onError(response){
                    vm.data = response.data;
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('A avut loc o eroare!')
                        .textContent('Toate campurile sunt obligatorii!')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {

                });

            })
        };
    }
})();
