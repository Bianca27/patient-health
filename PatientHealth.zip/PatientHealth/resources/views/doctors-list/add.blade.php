@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">Adaugare medic</div>
            <div class="panel-body">
                @if($errors->any())
                    <div class="alert alert-danger">
                        @foreach($errors->all() as $error)
                            <p>{{ $error }}</p>
                        @endforeach
                    </div>
                @endif
                {!! Form::open([
              'method' => 'POST',
              'url' => 'doctors-list/add'
                ]) !!}

                <div class="form-group">
                    {!! Form::label('name', 'Nume medic:', ['class' => 'control-label']) !!}
                    {!! Form::text('name', null, ['class' => 'form-control']) !!}
                </div>


                <div class="form-group">
                    {!! Form::label('specialization', 'Specializare:', ['class' => 'control-label']) !!}
                    {!! Form::text('specialization', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('clinics', 'Clinica:', ['class' => 'control-label']) !!}
                    {!! Form::select('clinic', $clinics, null, ['class' => 'form-control', 'placeholder' => 'Selecteaza o clinica']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('email', 'Email:', ['class' => 'control-label']) !!}
                    {!! Form::email('email', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('phone_nr', 'Numar de telefon:', ['class' => 'control-label']) !!}
                    {!! Form::text('phone_nr', null, ['class' => 'form-control']) !!}
                </div>
                <a href="{{ URL::previous() }}" class="blue">Inapoi la lista medici</a>

                {!! Form::submit('Adauga medic', ['class' => 'btn blue-button pull-right']) !!}
                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection