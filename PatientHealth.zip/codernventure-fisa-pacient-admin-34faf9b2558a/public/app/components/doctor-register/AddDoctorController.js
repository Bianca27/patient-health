(function () {
    'use strict';
    PatientFileApp.controller('AddDoctorController', AddDoctorController);
    function AddDoctorController($http, $location, $mdDialog) {
        var vm = this;
        $http.get('doctor/clinics').then(function(data){
            vm.clinics = data.data;
        });
        vm.addUserDoctor = function (user, ev) {

            var data = {
                name: vm.name,
                email: vm.email,
                specialization: vm.specialization,
                clinic: vm.clinic.id,
                password: vm.password
            };
            $http.post('doctor/register', data)
                .then(function onSuccess(response){
                    var data = response.data;
                    var status = response.status;

                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('Felicitari!')
                            .textContent('Contul tau a fost creat cu succes!')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('OK!')
                            .targetEvent(ev)
                    ).then(function() {
                        $location.path('/doctors-login');
                    });
                }).catch(function onError(response) {
                    vm.data = response.data;
                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('A avut loc o eroare!')
                            .textContent('')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('OK!')
                            .targetEvent(ev)
                    ).then(function () {

                    });
            });
        };
    }
})();

