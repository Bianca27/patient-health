<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Weight extends Model
{

    protected $fillable = [
        'weight_value', 'patient_id', 'added_at'
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [ 'added_at' ];

    public function patient()
    {
        $this->belongsTo(Patient::class);
    }

    public function getAddedAtAttribute($value) {

        return Carbon::parse($value)->format('d/m/Y');
    }
}
