<?php
namespace App\Http\Controllers;

use App\Doctor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Response;

class ChangePasswordDoctorsController extends Controller
{
    public function __construct()
    {
        Auth::shouldUse('doctor');
        $this->middleware('jwt.auth');
    }

    public function changePassword($id, Request $request)
    {
        $this->validate(request(), [
            'password' => 'required',

        ]);

        $password = $request->get('password');

        $user = Doctor::find($id);
        $doctor = Doctor::find($user->id);
        $doctor->password = bcrypt($password);
        $doctor->save();

        return Response::json(array('success' => true));

    }

}