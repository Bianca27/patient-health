<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Cholesterol extends Model
{
    protected $fillable = [
        'cholesterol_value', 'patient_id', 'added_at'
    ];

    protected $dates = [ 'added_at' ];

    public function patient()
    {
        $this->belongsTo(Patient::class);
    }

    public function getAddedAtAttribute($value) {

        return Carbon::parse($value)->format('d/m/Y');
    }
}
