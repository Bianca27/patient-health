PatientFileApp.config(function ($routeProvider, $locationProvider, $authProvider) {

    // Satellizer configuration that specifies which API
    // route the JWT should be retrieved from
    $authProvider.loginUrl = '/patient/login';

    $locationProvider.hashPrefix('');
    $routeProvider.when('/login', {
        templateUrl: 'app/components/login/login.html',
        controller: 'LoginController',
        controllerAs: 'user'
    });
    $routeProvider.when('/register', {
        templateUrl: 'app/components/register/register.html',
        controller: 'AddUserPatientController',
        controllerAs: 'addUser'
    });
    $routeProvider.when('/dashboard', {
        templateUrl: 'app/components/dashboard/dashboard.html',
        controller: 'DashboardController',
        controllerAs: 'dashboard'
    });

    $routeProvider.when('/password-recovery', {
        templateUrl: 'app/components/password-recovery/password-recovery.html',
        controller: 'PasswordRecoveryController',
        controllerAs: 'recover'
    });

    $routeProvider.when('/change-password', {
        templateUrl: 'app/components/change-password/change-password.html',
        controller: 'ChangePasswordController',
        controllerAs: 'change'
    });
    $routeProvider.when('/doctors', {
        templateUrl: 'app/components/doctors/doctors.html',
        controller: 'DoctorsController',
        controllerAs: 'doctors'
    });
    $routeProvider.when('/journal', {
        templateUrl: 'app/components/medical-journal/medical-journal.html',
        controller: 'MedicalJournalController',
        controllerAs: 'journal'
    });
    $routeProvider.when('/weight-chart', {
        templateUrl: 'app/components/weight-chart/weight-chart.html',
        controller: 'WeightChartController',
        controllerAs: 'weight'
    });
    $routeProvider.when('/cholesterol-chart', {
        templateUrl: 'app/components/cholesterol-chart/cholesterol-chart.html',
        controller: 'CholesterolChartController',
        controllerAs: 'cholesterol'
    });
    $routeProvider.when('/patient-file', {
        templateUrl: 'app/components/patient-file/patient-file.html',
        controller: 'PatientFileController',
        controllerAs: 'patient'
    });
    $routeProvider.when('/profile', {
        templateUrl: 'app/components/profile/profile.html',
        controller: 'ProfileController',
        controllerAs: 'profile'
    });
    $routeProvider.when('/edit-profile', {
        templateUrl: 'app/components/edit-profile/edit-profile.html',
        controller: 'EditProfileController',
        controllerAs: 'edit'
    });
    $routeProvider.when('/patient-file/:id', {
        templateUrl: 'app/components/patient-file-details/patient-file-details.html',
        controller: 'PatientFileDetailsController',
        controllerAs: 'patientDetails'
    });
    $routeProvider.when('/file/:id', {
        templateUrl: 'app/components/files/file.html',
        controller: 'FilesController',
        controllerAs: 'file'

    });
    $routeProvider.otherwise({ redirectTo: '/login' });
});

function loginTokenValidator($location, $q) {
    return {
        responseError: function(rejection) {
            var rejectionReasons = ['token_not_provided', 'token_expired', 'token_absent', 'token_invalid'];

            angular.forEach(rejectionReasons, function(value, key) {

                if(rejection.data.error === value) {

                    localStorage.removeItem('user');

                    $location.path('/login')
                }
            });

            return $q.reject(rejection);
        }
    }
}

PatientFileApp.factory('loginTokenValidator', loginTokenValidator)
    .config(function($httpProvider) {
        $httpProvider.interceptors.push('loginTokenValidator');
    });


PatientFileApp.run(function($rootScope, $location, $http, loginService) {

    // $stateChangeStart is fired whenever the state changes. We can use some parameters
    // such as toState to hook into details about the state as it is changing
    $rootScope.$on('$routeChangeStart', function() {

        // Grab the user from local storage and parse it to an object
        var user = JSON.parse(localStorage.getItem('user'));

        // If there is any user data in local storage then the user is quite
        // likely authenticated. If their token is expired, or if they are
        // otherwise not actually authenticated, they will be redirected to
        // the auth state because of the rejected request anyway


        if ($location.path() !== "/password-recovery" && $location.path() !== "/register") {
            if(user) {

                // The user's authenticated state gets flipped to
                // true so we can now show parts of the UI that rely
                // on the user being logged in
                $rootScope.authenticated = true;

                // Putting the user's data on $rootScope allows
                // us to access it anywhere across the app. Here
                // we are grabbing what is in local storage
                $rootScope.currentUser = user;

                // If the user is logged in and we hit the login route we don't need
                // to stay there and can send the user to the dashboard
                if($location.path() === "/login") {
                    $location.path('/dashboard');
                }
            } else {
                //We set it to false so we can hide the left menu
                $rootScope.authenticated = false;
                $location.path('/login');
            }
        }

    });
});
