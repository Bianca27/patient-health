﻿## Patient Health

Aplicația Patient Health este o aplicație care conține istoricul unui pacient, date personale ale pacientului, un istoric medical cu toate consultațiile și tratamentele efectuate, o evoluție a stării sale de sănătate precum și medicii care l-au tratat. Medicii pot vizualiza datele personale ale pacientului, istoricul său medical și pot adăuga o intervenție în momentul consultării pacientului, atașând fișiere precum rețete prescrise sau radiografii.

## Cerinte server

- Php 7.0.18

- MySql - latest

## Instalare aplicatie

Aplicatia este construita pe platforma Laravel si AngularJS

In ariva se gasesc toate fisierele necesare si nu este nevoie sa se descarce nimic.

Fisierele trebuie copiate intr-un director pe server.

In fisierul ENV sunt setarile pentru conectarea la baza de date.

DB_HOST=''

DB_DATABASE=''

DB_USERNAME=''

DB_PASSWORD=''

Fisierul sql cuprinde structura bazei de date si cateva contru demo.

Lista conturi demo:

### Admin

[http://patient-health.tk/login]

Utilizator:admin@gmail.com

Parola:123456

### Doctor

[http://patient-health.tk/doctors]

Nota - aceste interfete sunt doar pentru demonstratie in mod normal accessul se face din aplicatia de tableta.

Utilizator: apostol@medlife.com

Parola: 123456

### Pacient

[http://patient-health.tk/#/login]

Nota - aceste interfete sunt doar pentru demonstratie in mod normal accessul se face din aplicatia de mobil.

Utilizator: ana@gmail.com

Parola: 123456

## Developer

Bianca Maria Radu - [bianca.radu19@gmail.com]