(function () {
    'use strict';
    PatientFileApp.controller('patientWeightEvolutionController', patientWeightEvolutionController);
    function patientWeightEvolutionController($http, $routeParams, $mdDialog) {
        var vm = this;
        vm.getData = function () {

            vm.dataWeight = [];

            $http.get('doctor/patient-weight-evolution/' + $routeParams.id)
                .then(function(response) {
                    vm.weight = response.data;
                    angular.forEach(vm.weight, function(weight){
                        vm.dataWeight.push(
                            {
                                "label": weight.added_at,
                                "value": weight.weight_value
                            }
                        )
                    });
                });

            return vm.dataWeight;
        };

        vm.back = function(){
            window.history.back();
        }

        vm.drawChart = function () {

            vm.dataSource = {
                "chart": {
                    "caption": "Evolutie greutate",
                    "subCaption":'',
                    "xAxisName": "Data",
                    "yAxisName": "Greutate (kg)",
                    "numberPrefix": "kg",
                    "paletteColors": "#27BEC4",
                    "bgColor": "#ffffff",
                    "borderAlpha": "20",
                    "canvasBorderAlpha": "0",
                    "usePlotGradientColor": "0",
                    "plotBorderAlpha": "10",
                    "placevaluesInside": "1",
                    "rotatevalues": "1",
                    "valueFontColor": "#ffffff",
                    "showXAxisLine": "1",
                    "xAxisLineColor": "#999999",
                    "divlineColor": "#999999",
                    "divLineDashed": "1",
                    "showAlternateHGridColor": "0",
                    "subcaptionFontBold": "0",
                    "subcaptionFontSize": "14"
                },

                "data": vm.getData()
            };
        };

        vm.drawChart();
        vm.addWeight = function(weight, ev){

            var data = {
                weight_value: vm.weight_value,
                added_at: vm.added_at
            };

            $http.post('doctor/add-weight/'+ $routeParams.id, data)
                .then(function onSuccess(response){
                    var data = response.data;
                    var status = response.status;

                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('Felicitari!')
                            .textContent('Greutatea a fost adaugata cu success!')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('OK!')
                            .targetEvent(ev)
                    ).then(function() {
                        vm.drawChart();

                        vm.weight_value = '';
                    });

                }).catch(function onError(response) {
                // Handle error
                var data = response.data;
                var status = response.status;
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('Campul greutate este obligatoriu')
                        .textContent('')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                );
            });
        }


    }
})();
