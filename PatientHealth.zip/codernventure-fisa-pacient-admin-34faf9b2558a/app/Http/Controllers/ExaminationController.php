<?php

namespace App\Http\Controllers;

use App\Examination;

use Illuminate\Support\Facades\Auth;

class ExaminationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['clinics', 'doctors-list', 'examinations']);

    }

    public function index()
    {
        $examinations = Examination::with('doctor')->get();

        return view('examinations/examinations', compact('examinations'));
    }
    public function show(Examination $examination)
    {

        return view('examinations.show', compact('examination'));
    }
}
