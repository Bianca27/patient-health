@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-body">
                <h1>Adaugare pacient</h1>
                <hr>
                @if($errors->any())
                    <div class="alert alert-danger">
                        @foreach($errors->all() as $error)
                            <p>{{ $error }}</p>
                        @endforeach
                    </div>
                @endif
                {!! Form::open([
                'url' => 'patients/patients'
                ]) !!}
                <div class="form-group">
                    {!! Form::label('lastname', 'Nume:', ['class' => 'control-label']) !!}
                    {!! Form::text('lastname', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('firstname', 'Prenume:', ['class' => 'control-label']) !!}
                    {!! Form::text('firstname', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('address', 'Adresa:', ['class' => 'control-label']) !!}
                    {!! Form::text('address', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('cnp', 'CNP:', ['class' => 'control-label']) !!}
                    {!! Form::text('cnp', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('birthday', 'Data nasterii:', ['class' => 'control-label']) !!}
                    {!! Form::date('birthday', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('email', 'Email:', ['class' => 'control-label']) !!}
                    {!! Form::email('email', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('phone_nr', 'Nr. de telefon:', ['class' => 'control-label']) !!}
                    {!! Form::text('phone_nr', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('emergency_contact_nr', 'Contact de urgenta:', ['class' => 'control-label']) !!}
                    {!! Form::text('emergency_contact_nr', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('blood_type', 'Grupa sanguina:', ['class' => 'control-label']) !!}
                    {!! Form::text('blood_type', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('alergies', 'Alergies:', ['class' => 'control-label']) !!}
                    {!! Form::text('alergies', null, ['class' => 'form-control']) !!}
                </div>
                <a href="{{ URL::previous() }}" class="blue">Inapoi la lista pacienti</a>
                {!! Form::submit('Adaugare pacient', ['class' => 'btn blue-button pull-right']) !!}

                {!! Form::close() !!}
            </div>
        </div>
    </div>


@endsection