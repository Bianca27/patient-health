<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Clinic;


class ClinicController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['clinics', 'doctors-list']);
    }

    public function index()
    {

        $clinics = DB::table('clinics')->paginate(5);

        return view('/clinics/clinics', compact('clinics'));
    }


    public function edit($id)
    {

        $clinic = Clinic::findOrFail($id);


        return view('clinics.edit', compact('clinic', $clinic));


    }

    public function update($id, Request $request)
    {
        $clinic = Clinic::findOrFail($id);

        $this->validate($request, [
            'name' => 'required',
            'address' => 'required'
        ]);


        $input = $request->all();

        $clinic->fill($input)->save();

        return redirect('clinics/clinics');
    }
}
