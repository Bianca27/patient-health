(function () {
    'use strict';
    PatientFileApp.factory('cholesterolService', cholesterolService);
    function cholesterolService($http) {

        // get pe ruta laravel
        var cholesterolService = $http.get('/patient/cholesterol-evolution');

        return {
            get: function () {
                return cholesterolService;
            }
        }
    }
})();