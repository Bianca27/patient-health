<?php

namespace App\Http\Controllers;

use App\Doctor;

use App\Clinic;

use Illuminate\Http\Request;

class DoctorController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['clinics', 'doctors']);
    }

    public function index()
    {
        $doctors = Doctor::with('clinic')->paginate(5);

        return view('/doctors-list/doctors', compact('doctors', $doctors));
    }


    public function edit($id)
    {
        $clinics = Clinic::all(['id', 'name'])->pluck('name', 'id');

        $doctor = Doctor::findOrFail($id);

        return view('doctors-list.edit', compact('clinics', 'doctor'));
    }

    public function update($id, Request $request)
    {
        $doctor = Doctor::findOrFail($id);

        $this->validate($request, [
            'name' => 'required',
            'specialization' => 'required',
            'email' => 'required',
            'phone_nr' => 'required'
        ]);

        $doctor->update([
            'name' => request('name'),
            'specialization' => request('specialization'),
            'clinic_id' => request('clinic'),
            'email' => request('email'),
            'phone_nr' => request('phone_nr')
        ]);


        return redirect('doctors-list/doctors');
    }
}
