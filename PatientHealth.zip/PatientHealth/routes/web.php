<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Auth::routes();

Route::get('/home', 'HomeController@index');

Route::prefix('patient')->group(function(){

    Route::post('/login', 'Auth\PatientLoginController@login');

    Route::post('/register', 'RegisterPatientController@store');

    Route::get('/user', 'Auth\PatientLoginController@getAuthenticatedUser');

    Route::get('/profile', 'PatientProfileController@index');

    Route::get('/edit/{id}', 'PatientProfileController@edit');

    Route::post('/update/{id}', 'PatientProfileController@update');

    Route::get('/patient-file', 'PatientFileController@index');

    Route::get('/details/{id}', 'PatientFileController@showExamination');

    Route::get('/files/{id}','PatientFileController@getUploadedFiles');

    Route::get('/file/{id}','PatientFileController@getFile');

    Route::get('/patient-doctors', 'PatientDoctorsController@index');

    Route::get('/doctor-requests', 'PatientDoctorsController@getAccessRequests');

    Route::get('/weight-evolution', 'WeightController@index');

    Route::post('/weight-evolution/add', 'WeightController@store');

    Route::get('/cholesterol-evolution', 'CholesterolController@index');

    Route::patch('/patient-doctors/deactivate/{id}', 'PatientDoctorsController@deactivate');

    Route::patch('/patient-doctors/activate/{id}', 'PatientDoctorsController@activate');

    Route::patch('/patient-doctors/accept/{id}', 'PatientDoctorsController@accept');

    Route::post('/reset-password', 'ResetPasswordController@resetPassword');

    Route::post('/change-password/{id}', 'PatientProfileController@changePassword');

});

Route::prefix('doctor')->group(function() {
    Route::get('/clinics', 'RegisterDoctorController@index');

    Route::post('/register', 'RegisterDoctorController@store');

    Route::post('/login', 'Auth\DoctorLoginController@login')->name('doctor.login.submit');

    Route::get('/', 'DoctorAsUserController@index')->name('doctor.dashboard');

    Route::get('/user', 'Auth\DoctorLoginController@getAuthenticatedUser');

    Route::get('/patients-list', 'PatientsListController@index');

    Route::get('/all-patients', 'AllPatientsController@index');

    Route::post('/all-patients/{id}', 'AllPatientsController@access');

    Route::get('/add-patient', 'AddPatientController@index');

    Route::post('/add-patient', 'AddPatientController@store');

    Route::get('/patients-list/{id}', 'PatientsListController@show');

    Route::get('/get-patient-details/{id}', 'PatientsListController@getPatientDetails');

    Route::get('/patient-weight-evolution/{id}', 'PatientsListController@getWeightEvolution');

    Route::get('/patient-cholesterol-evolution/{id}', 'PatientsListController@getCholesterolEvolution');

    Route::post('/add-cholesterol/{id}', 'PatientsListController@addCholesterol');

    Route::post('/add-weight/{id}', 'PatientsListController@addWeight');

    Route::get('/examination-details/{id}', 'PatientsListController@examination');

    Route::get('/patients-list/add-examination/{id}', 'AddExaminationController@index');

    Route::post('/edit-examination/edit/{id}', 'EditExaminationController@edit');

    Route::post('/patients-list/add-examination/{id}', 'AddExaminationController@store');

    Route::post('/examination/upload/', 'AddExaminationController@upload');

    Route::post('/examination-details/{id}', 'PatientsListController@store');

    Route::post('/reset-password', 'ResetPasswordDoctorsController@resetPassword');

    Route::post('/change-password/{id}', 'ChangePasswordDoctorsController@changePassword');
});

Route::get('/examination_photo/{name}', function ($name) {
    $uploads = storage_path().'/app/public/uploads/';
    try {
        header("Content-type: image/jpg");
        echo file_get_contents($uploads.$name);
    } catch (\Exception $e){
        return $e->getMessage();
    }

});

Route::get('/clinics/clinics', 'ClinicController@index');

Route::delete('/clinics/{clinic}', 'ClinicController@delete');

Route::get('/clinics/edit/{id}', 'ClinicController@edit');

Route::patch('/clinics/update/{id}', 'ClinicController@update');

Route::get('/clinics/add', 'AddClinicController@index');

Route::post('/clinics/add', 'AddClinicController@store');

Route::get('/doctors-list/doctors', 'DoctorController@index');

Route::get('/patients/patients', 'PatientController@index');

Route::get('/doctors-list/edit/{id}', 'DoctorController@edit');

Route::patch('/doctors-list/update/{id}', 'DoctorController@update');

Route::get('/doctors-list/add', 'AddDoctorController@index');

Route::post('/doctors-list/add', 'AddDoctorController@store');

Route::get('patients/add', 'PatientController@create');

Route::post('patients/patients', 'PatientController@store');

Route::delete('/patients/destroy/{id}', 'PatientController@destroy');

Route::get('patients/edit/{id}', 'PatientController@edit');

Route::patch('/patients/update/{id}', 'PatientController@update');