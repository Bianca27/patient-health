(function () {
    'use strict';
    PatientFileApp.controller('LoginController', LoginController);
    function LoginController(loginService) {
        var vm = this;
        vm.message='';
        vm.login = function(data){
            loginService.login(data, vm);
        }
    }
})();

