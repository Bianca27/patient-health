
(function () {
    'use strict';
    PatientFileApp.controller('FilesController', FilesController);
    function FilesController($http, $routeParams) {
      var vm = this;

        $http.get('patient/file/' + $routeParams.id).then(function(data){
            vm.file = data.data;
            console.log(vm.file.filename);

        })
    }

})();
