(function () {
    'use strict';
    PatientFileApp.controller('MainDashboardController', MainDashboardController);
    function MainDashboardController() {

    };

})();
