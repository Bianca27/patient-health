<!DOCTYPE html>
<html>
<head>
    <title>Creare cont</title>
</head>
<body>

<h1>Salut, {{$user}}</h1>
<p>Parola ta pentru acest cont este: {{ $newPass }}</p>

<p>Parola este generata automat de sistem, te rugam sa o schimbi la prima conectare!</p>

</body>
</html>