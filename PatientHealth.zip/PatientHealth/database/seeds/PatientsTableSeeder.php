 <?php

use Illuminate\Database\Seeder;

class PatientsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $patients = [
            [
                'firstname' => 'ana',
                'lastname' => 'maria',
                'cnp' => '2900723086789',
                'birthday' => '1990-07-23',
                'email' => 'ana@gmail.com',
                'password' => bcrypt('123456'),
                'phone_nr' => 'F',
                'address' => 'F',
                'emergency_contact_nr' => 'F',
                'blood_type' => 'F',
                'alergies' => 'F'

            ],

            [
                'firstname' => 'bianca',
                'lastname' => 'radu',
                'cnp' => '2930827080038',
                'birthday' => '1993-08-27',
                'email' => 'bianca@gmail.com',
                'password' => bcrypt('123456'),
                'phone_nr' => 'F',
                'address' => 'F',
                'emergency_contact_nr' => 'F',
                'blood_type' => 'F',
                'alergies' => 'F'
            ],

            [
                'firstname' => 'popescu',
                'lastname' => 'ion',
                'cnp' => '1670814085645',
                'birthday' => '1967-08-14',
                'email' => 'ion@gmail.com',
                'password' => bcrypt('123456'),
                'phone_nr' => 'F',
                'address' => 'F',
                'emergency_contact_nr' => 'F',
                'blood_type' => 'F',
                'alergies' => 'F'
            ],
        ];

        foreach($patients as $patient){
            DB::table('patients')-> insert([$patient]);
        }

    }
}
