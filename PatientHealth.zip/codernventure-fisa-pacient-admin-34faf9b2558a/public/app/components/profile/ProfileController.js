(function () {
    'use strict';
    PatientFileApp.controller('ProfileController', ProfileController);
    function ProfileController(userInfo) {
        var vm = this;
        userInfo.get().then(function (data) {
            vm.userInfo = data.data;
            vm.userInfo.birthday = new Date(vm.userInfo.birthday);
        });
    }
})();

