<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Hash;

use App\Doctor;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;
use Log;

class ResetPasswordDoctorsController extends Controller
{
    /**
     * @param Request $request
     */
    public function resetPassword(Request $request){

        $email = $request->get('email');
        $user = Doctor::where('email', '=', $email)->get()->first();


        $doctor = Doctor::find($user->id);
        $newPass = str_random(8);
        $doctor->password = Hash::make($newPass);
        $doctor->save();

        //send password by email to the user
        Mail::send('auth.passwords.resetare-parola', ['newPass' => $newPass, 'user' => $user->name], function ($message) use ($doctor) {
            $message->from('office@patient-health.tk', 'Patient Health');
            $message->to($doctor->email, '')->subject("Parola dumneavoastra a fost resetata");
        });
    }
}
