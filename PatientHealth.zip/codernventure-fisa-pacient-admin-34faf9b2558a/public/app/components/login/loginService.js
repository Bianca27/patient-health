'use strict';
PatientFileApp.factory('loginService', function($http, $mdDialog, $location, $rootScope, $auth){
    var vm = this;
    return{
        login:function(data, scope, ev){

            var credentials = {
                email: scope.email,
                password: scope.password
            };

            // Use Satellizer's $auth service to login
            $auth.login(credentials).then(function() {

                // Return an $http request for the now authenticated
                // user so that we can flatten the promise chain
                return $http.get('patient/user');

                // Handle errors
            }, function(error) {
                vm.loginError = true;
                vm.loginErrorText = 'Autentificare esuata, te rog verifica datele de conectare!';
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('Autentificare esuata!')
                        .textContent('Te rog verifica datele de conectare!')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {
                    $location.path('/login');
                });

                // Because we returned the $http.get request in the $auth.login
                // promise, we can chain the next promise to the end here
            }).then(function(response) {

                // Stringify the returned data to prepare it
                // to go into local storage
                var user = JSON.stringify(response.data.user);

                // Set the stringified user data into local storage
                localStorage.setItem('user', user);

                // The user's authenticated state gets flipped to
                // true so we can now show parts of the UI that rely
                // on the user being logged in
                $rootScope.authenticated = true;

                // Putting the user's data on $rootScope allows
                // us to access it anywhere across the app
                $rootScope.currentUser = response.data.user;

                $location.path('/dashboard');

            });
        },
        logout:function(){

            $auth.logout().then(function() {

                // Remove the authenticated user from local storage
                localStorage.removeItem('user');

                // Flip authenticated to false so that we no longer
                // show UI elements dependant on the user being logged in
                $rootScope.authenticated = false;

                // Remove the current user info from rootscope
                $rootScope.currentUser = null;

                $location.path('/login');
            });

        }
    }

});
