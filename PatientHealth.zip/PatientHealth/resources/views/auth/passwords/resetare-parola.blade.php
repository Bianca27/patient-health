<!DOCTYPE html>
<html>
<head>
    <title>Resetare parola</title>
</head>
<body>

<h1>Salut, {{$user}}</h1>
<h3>Parola ta a fost resetata</h3>
<p>Parola noua este: {{ $newPass }}</p>

<p>Parola este generata automat de sistem, te rugam sa o schimbi la prima conectare!</p>

</body>
</html>