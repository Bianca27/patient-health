(function () {
    'use strict';
    PatientFileApp.controller('PatientFileController', PatientFileController);
    function PatientFileController($http) {
        var vm = this;
        $http.get('/patient/patient-file').then(function(data){
             vm.examinations = data.data;
             angular.forEach(vm.examinations, function(examinations){
                 examinations.created_at = new Date(examinations.created_at);
             })
         });
        vm.search = '';
    }
})();
