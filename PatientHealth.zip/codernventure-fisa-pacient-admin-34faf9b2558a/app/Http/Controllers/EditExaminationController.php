<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Examination;
use App\Patient;
use Response;
use Auth;

class EditExaminationController extends Controller
{
    public function __construct()
    {
        Auth::shouldUse('doctor');
        $this->middleware('jwt.auth');
    }

    public function edit(Request $request,$id)
    {

        $this->validate(request(), [
            'title' => 'required',
            'simptoms' => 'required',
            'diagnosis' => 'required',
            'treatment' => 'required'
        ]);

        $examination = Examination::find($id);
        $patient = Patient::where('id', $examination->patient_id)->get()->first();

        if($patient == null){
            return Response::json(array('success' => false), 404);
        }
        if(!$patient->is_patient) {
            return Response::json(array('success' => false), 403);
        }

        $examination->title = request('title');
        $examination->simptoms = request('simptoms');
        $examination->diagnosis = request('diagnosis');
        $examination->treatment = request('treatment');
        $examination->save();

        $examinationId = $examination->id;

        return Response::json(array('success' => true, 'examinationId' => $examinationId));
    }
}
