(function () {
    'use strict';
    PatientFileApp.controller('DoctorsLoginController', DoctorsLoginController);
    function DoctorsLoginController(DoctorsLoginService) {
        var vm = this;
        vm.message='';
        vm.login = function(data){
            DoctorsLoginService.login(data, vm);
        }
    }
})();


