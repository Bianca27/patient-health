(function () {
    'use strict';
    PatientFileApp.factory('weightService', weightService);
    function weightService($http) {

        var weightService = $http.get('/patient/weight-evolution');
        return {
            get: function () {
                return weightService;
            }
        }
    }
})();