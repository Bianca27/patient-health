<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;

use App\Patient;

use App\Doctor;

use App\DoctorPatient;

use Illuminate\Support\Facades\Auth;

use Response;


class AllPatientsController extends Controller
{
    public function __construct()
    {
        Auth::shouldUse('doctor');
        $this->middleware('jwt.auth');
    }

    public function index(Request $request){
        $id = Auth::user()->id;
        $patients = Patient::with('getDoctors', 'requests')->orderBy('lastname')->get();
        $show  = false;
        $keyword = $request->input('keyword');

        if($keyword!=''){
            $show = true;
            $patients = Patient::with('getDoctors', 'requests')->orderBy('lastname')->search($keyword)->get();
            $keyword = '';
        }

        return Response::json($patients);
    }

    public function access($id){
        $doctorId = Auth::user()->id;

        $request = DoctorPatient::where('patient_id', $id)->where('doctor_id', $doctorId)->get()->first();

        if($request) {
            $request->access_requested = 1;
            $request->save();
        }else {
            $doctorPatient = new DoctorPatient;
            $doctorPatient->patient_id = $id;
            $doctorPatient->doctor_id = $doctorId;
            $doctorPatient->active = 0;
            $doctorPatient->access_requested = 1;
            $doctorPatient->save();
        }

        $notification = array(
            'message' => 'I am a successful message!',
            'alert-type' => 'success'
        );

        return redirect('doctor/all-patients')->with($notification);
    }
}
