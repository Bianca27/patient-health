<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Hash;

use App\Patient;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;
use Log;

class ResetPasswordController extends Controller
{
    /**
     * @param Request $request
     */
    public function resetPassword(Request $request){

        $email = $request->get('email');
        $user = Patient::where('email', '=', $email)->get()->first();


        $patient = Patient::find($user->id);
        $newPass = str_random(8);
        $patient->password = Hash::make($newPass);
        $patient->save();

        //send password by email to the user
        Mail::send('auth.passwords.resetare-parola', ['newPass' => $newPass, 'user' => $user->firstname], function ($message) use ($patient) {
            $message->from('office@patient-health.tk', 'Patient Health');
            $message->to($patient->email, '')->subject("Parola dumneavoastra a fost resetata");
        });
    }
}
