(function () {
    'use strict';
    PatientFileApp.controller('MenuController', MenuController);
    function MenuController($scope, $mdSidenav, loginService) {
        $scope.toggleLeft = buildToggler('left');
        $scope.toggleRight = buildToggler('right');
        function buildToggler(componentId) {
            return function() {
                $mdSidenav(componentId).toggle();
            }
        }
        $scope.logout = function(){
            loginService.logout();
        }
    }

})();
