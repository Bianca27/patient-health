<?php

use Illuminate\Database\Seeder;

class DoctorsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $doctors = [
            [
                'name' => 'Apostol Ana Maria',
                'clinic_id' => 1,
                'specialization'=> 'pediatrie',
                'email' => 'apostol@medlife.com',
                'password' => bcrypt('123456')
            ],
            [
                'name' => 'Balta Dan-Seni',
                'clinic_id' => 2,
                'specialization'=> 'ORL',
                'email' => 'balta@medlife.com',
                'password' => bcrypt('123456')
            ],
            [
                'name' => 'Angelescu Corina',
                'clinic_id' => 3,
                'specialization'=> 'Gastroentorologie',
                'email' => 'angi@medlife.com',
                'password' => bcrypt('123456')
            ],
            [
                'name' => 'Dana Sorina Alexandrescu',
                'clinic_id' => 2,
                'specialization'=> 'Pneumologie',
                'email' => 'dana@medlife.com',
                'password' => bcrypt('123456')
            ],
            [
                'name' => 'Octavian Brumaru',
                'clinic_id' => 3,
                'specialization'=> 'Psihiatrie',
                'email' => 'brumaru@medlife.com',
                'password' => bcrypt('123456')
            ],
            [
                'name' => 'Constantin Carstea',
                'clinic_id' => 1,
                'specialization'=> 'Medic de familie',
                'email' => 'carstea@medlife.com',
                'password' => bcrypt('123456')
            ],
        ];
        foreach($doctors as $doctor){
            DB::table('doctors')-> insert([$doctor]);
        }
    }
}
