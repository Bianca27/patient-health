(function () {
    'use strict';
    PatientFileApp.controller('patientCholesterolEvolutionController', patientCholesterolEvolutionController);
    function patientCholesterolEvolutionController($http, $mdDialog, $routeParams, $location) {
        var vm = this;
        vm.getData = function () {

            vm.dataCholesterol = [];

            $http.get('doctor/patient-cholesterol-evolution/' + $routeParams.id)
                .then(function(response) {

                    vm.cholesterol = response.data;

                    angular.forEach(vm.cholesterol, function(cholesterol){

                        vm.dataCholesterol.push(
                            {
                                "label": cholesterol.added_at,
                                "value": cholesterol.cholesterol_value
                            }
                        )
                    });
                });

            return vm.dataCholesterol;
        };

        vm.back = function(){
            window.history.back();
        }

        vm.drawChart = function () {

            vm.dataSource = {
                "chart": {
                    "caption": "Evolutie colesterol",
                    "subCaption":'',
                    "xAxisName": "Data",
                    "yAxisName": "Cholesterol (mg/dl)",
                    "numberPrefix": "mg/dl",
                    "paletteColors": "#27BEC4",
                    "bgColor": "#ffffff",
                    "borderAlpha": "20",
                    "canvasBorderAlpha": "0",
                    "usePlotGradientColor": "0",
                    "plotBorderAlpha": "10",
                    "placevaluesInside": "1",
                    "rotatevalues": "1",
                    "valueFontColor": "#ffffff",
                    "showXAxisLine": "1",
                    "xAxisLineColor": "#999999",
                    "divlineColor": "#999999",
                    "divLineDashed": "1",
                    "showAlternateHGridColor": "0",
                    "subcaptionFontBold": "0",
                    "subcaptionFontSize": "14"
                },

                "data": vm.getData()
            };
        };

        vm.drawChart();

        vm.addCholesterol = function(cholesterol, ev){

            var data = {
                cholesterol_value: vm.cholesterol_value,
                added_at: vm.added_at
            };

            $http.post('doctor/add-cholesterol/' + $routeParams.id, data)
                .then(function onSuccess(response){
                    var data = response.data;
                    var status = response.status;

                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('Felicitari!')
                            .textContent('Colesterolul a fost adaugat cu success!')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('OK!')
                            .targetEvent(ev)
                    ).then(function() {
                        vm.drawChart();

                        vm.cholesterol_value = '';
                    });

                }).catch(function onError(response) {
                // Handle error
                var data = response.data;
                var status = response.status;
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('Campul colesterol este obligatoriu')
                        .textContent('')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                );
            });
        }
    }
})();
