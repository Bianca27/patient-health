@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">Editare clinica</div>
            <div class="panel-body">
                {!! Form::model($clinic, [
                    'method' => 'PATCH',
                    'url' => ['clinics/update', $clinic->id]
                ]) !!}

                <div class="form-group">
                    {!! Form::label('name', 'Name:', ['class' => 'control-label']) !!}
                    {!! Form::text('name', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('address', 'Address:', ['class' => 'control-label']) !!}
                    {!! Form::textarea('address', null, ['class' => 'form-control']) !!}
                </div>
                <a href="clinics/clinics">Inapoi</a>
                {!! Form::submit('Editeaza Clinica', ['class' => 'btn blue-button pull-right']) !!}

                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection