<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Examination extends Model
{

    public function doctor(){

        return $this->belongsTo(Doctor::class);
    }

    public function patient(){

        return $this->belongsTo(Patient::class);
    }

    public function clinic()
    {
        return $this->belongsTo(Clinic::class);
    }

    public function file(){

        return $this->hasMany(File::class);
    }


    protected $fillable = ['title',  'clinic_id', 'simptoms', 'diagnosis', 'treatment', 'patient_id', 'doctor_id'];
}
