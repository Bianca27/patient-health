(function () {
    'use strict';
    PatientFileApp.controller('DashboardController', DashboardController);
    function DashboardController($rootScope, $http, loginService) {
        var vm = this;
        $rootScope.notifications = 0;
        $http.get('patient/doctor-requests').then(function(data) {
            $rootScope.notifications = data.data;
        });
        vm.logout = function(){
            loginService.logout();
        }

    }
})();
