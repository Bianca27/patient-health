<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $users = [
            [
                'name' => 'admin',
                'email' => 'admin@gmail.com',
                'password' => bcrypt('123456')
            ],

            [
                'name' => 'test',
                'email' => 'test@gmail.com',
                'password' => bcrypt('123456')
            ]
        ];

        foreach($users as $user){
            DB::table('users')-> insert([$user]);
        }

    }
}
