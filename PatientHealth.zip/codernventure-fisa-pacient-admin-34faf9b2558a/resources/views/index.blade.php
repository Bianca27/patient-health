<html lang="en" >
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/angular_material/1.1.0/angular-material.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/angular-xeditable/0.6.0/css/xeditable.min.css">
    <link rel="stylesheet"  href="assets/css/style.css" type="text/css" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,400italic">
    <link  rel="stylesheet" href="assets/css/style.css" type="text/css"/>
</head>
<body ng-app="PatientFileApp" ng-cloak>
<div id="main">
    <section layout="row" ng-if="authenticated" flex layout-align="center center" ng-controller="MenuController" >
        <md-toolbar  layout="row"  class="md-toolbar-tools" style="background-color: #27BEC4">
            <md-button  ng-click="toggleLeft()" style="background-color: #27BEC4">
                <i class="material-icons" style="float:left;">menu</i>
            </md-button>
            <div ng-if="notifications" style="background-color: red; border-radius: 50%; padding:1px 7px; font-size:0.8em;"><a href="#/doctors">@{{notifications}}</a></div>
            <md-button>
                <a href="#/change-password" style="margin-left: 100px;">Schimba parola</a>
            </md-button>

        </md-toolbar>
        <md-sidenav class="md-sidenav-left" md-component-id="left"
                    md-whiteframe="4">
            <md-toolbar layout="row" style="background-color: #27BEC4;">
                <i class="material-icons account-circle">account_circle</i>
                <h1 class="md-toolbar-tools">@{{ currentUser.firstname }} @{{ currentUser.lastname }}</h1>
                <i class="material-icons close-button" ng-click="toggleLeft()">close</i>
            </md-toolbar>
            <md-content layout-margin>
                <md-list>
                    <md-list-item ng-click="toggleLeft()" href="#/dashboard" >
                        <i class="material-icons left-menu-item">home</i>
                        Home
                    </md-list-item>
                    <md-divider ></md-divider>
                    <md-list-item ng-click="toggleLeft()" href="#/profile" >
                        <i class="material-icons left-menu-item">perm_identity</i>
                        Profil
                    </md-list-item>
                    <md-divider ></md-divider>
                    <md-list-item ng-click="toggleLeft()"  href="#/patient-file">
                        <i class="material-icons left-menu-item">history</i>
                        Istoric Pacient
                    </md-list-item>
                    <md-divider ></md-divider>
                    <md-list-item ng-click="toggleLeft()" href="#/doctors">
                        <i class="material-icons left-menu-item">view_list</i>
                        Medici
                    </md-list-item>
                    <md-divider ></md-divider>
                    <md-list-item ng-click="toggleLeft()" href="#/journal">
                        <i class="material-icons left-menu-item">receipt</i>
                        Jurnal Medical
                    </md-list-item>
                    <md-divider ></md-divider>
                    <md-list-item ng-click="toggleLeft()" href="#/change-password">
                        <i class="material-icons left-menu-item">build</i>
                        Schimba parola
                    </md-list-item>
                    <md-divider ></md-divider>
                    <md-list-item  ng-click="logout(); toggleLeft()">
                        <i class="material-icons left-menu-item">power_settings_new</i>
                        Logout
                    </md-list-item>
                </md-list>

            </md-content>
        </md-sidenav>
        <md-card-content>
        </md-card-content>
    </section>
    <div ng-view></div>
</div>
<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.6.1/angular.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.1/angular-route.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.1/angular-resource.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.6.1/angular-animate.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.6.1/angular-aria.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.6.1/angular-messages.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/angular_material/1.1.4/angular-material.min.js"></script>
<script src="node_modules/md-collection-pagination/dist/md-collection-pagination.min.js" charset="utf-8"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular-material-icons/0.7.1/angular-material-icons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular-xeditable/0.6.0/js/xeditable.min.js"></script>
<script src="node_modules/satellizer/dist/satellizer.js"></script>
<script src="charts/fusioncharts.js"></script>
<script src="charts/fusioncharts.charts.js"></script>

<script src="charts/angular-fusioncharts.min.js"></script>
<script src="app/app.module.js?v=2"></script>
<script src="app/app.routes.js?v=2"></script>
<script src="app/components/dashboard/DashboardController.js"></script>
<script src="app/components/profile/ProfileController.js"></script>
<script src="app/components/profile/profileService.js"></script>
<script src="app/components/doctors/DoctorsController.js"></script>
<script src="app/components/patient-file/PatientFileController.js"></script>
<script src="app/components/patient-file-details/PatientFileDetailsController.js"></script>
<script src="app/components/left-menu/MenuController.js"></script>
<script src="app/components/login/LoginController.js?v=1"></script>
<script src="app/components/login/loginService.js"></script>
<script src="app/components/edit-profile/EditProfileController.js"></script>
<script src="app/components/password-recovery/PasswordRecoveryController.js"></script>
<script src="app/components/change-password/ChangePasswordController.js?v=1"></script>
<script src="app/components/medical-journal/MedicalJournalController.js"></script>
<script src="app/components/weight-chart/WeightChartController.js"></script>
<script src="app/components/weight-chart/weightService.js"></script>
<script src="app/components/cholesterol-chart/CholesterolChartController.js"></script>
<script src="app/components/cholesterol-chart/cholesterolService.js"></script>
<script src="app/components/register/addUserPatientController.js"></script>
<script src="app/components/patient-file/examinationService.js"></script>
<script src="app/components/add-patient/matchPassword.js?v=1"></script>
<script src="app/components/files/FilesController.js"></script>
</body>
</html>
