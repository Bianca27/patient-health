<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;

use App\Weight;

use Illuminate\Support\Facades\Auth;

use Response;

class WeightController extends Controller
{
    public function __construct()
    {
        Auth::shouldUse('patient');
        $this->middleware('jwt.auth');
    }

    public function index()
    {
        $id = Auth::user()->id;

        $weight = Weight::where('patient_id', $id)->orderBy('added_at', 'asc')->get();

        return Response::json($weight);
    }

    public function store()
    {
        $this->validate(request(), [
            'weight_value' => 'required',
            'added_at' => 'required'
        ]);

        $carbon = new Carbon(request('added_at'));
        $dateToCorrectTimezone =  $carbon->addHour(3);

        Weight::create([
            'weight_value' => request('weight_value'),
            'patient_id' => Auth::user()->id,
            'added_at' => $dateToCorrectTimezone
        ]);

        return Response::json(array('success' => true));
    }

}
