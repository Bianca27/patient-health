<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Cholesterol;

use Illuminate\Support\Facades\Auth;

use Response;


use Carbon\Carbon;

class CholesterolController extends Controller
{
    public function __construct()
    {
        Auth::shouldUse('patient');
        $this->middleware('jwt.auth');
    }


    public function index()
    {
        $id = Auth::user()->id;

        $cholesterol = Cholesterol::where('patient_id', $id)->orderBy('added_at', 'asc')->get();

        return Response::json($cholesterol);
    }


}
