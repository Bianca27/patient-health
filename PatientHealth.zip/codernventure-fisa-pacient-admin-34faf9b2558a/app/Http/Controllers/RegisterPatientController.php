<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Patient;
use Response;

class RegisterPatientController extends Controller
{

    public function store()
    {
        $this->validate(request(), [
            'lastname' => 'required',
            'firstname' => 'required',
            'cnp' => 'required|unique:patients',
            'email' => 'required|unique:patients',
            'password' => 'required|min:6',
        ]);

        Patient::create([
            'lastname' => request('lastname'),
            'firstname' => request('firstname'),
            'cnp' => request('cnp'),
            'email' => request('email'),
            'password'=>bcrypt(request('password'))
        ]);

        return Response::json(array('success' => true));
    }
}
