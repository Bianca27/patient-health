(function () {
    'use strict';
    PatientFileApp.controller('PatientDetailsController', PatientDetailsController);
    function PatientDetailsController($mdDialog, $http, examinationsService, $routeParams) {
        var vm = this;

        vm.search = '';
        vm.examinations = [];

        var patient = $http.get('doctor/get-patient-details/' + $routeParams.id).then(function(data) {
            vm.patient = data.data;
        });

        var examinations = $http.get('doctor/patients-list/' + $routeParams.id).then(function(data) {
            vm.examinations = data.data;
            angular.forEach(vm.examinations, function(examinations){
                examinations.created_at = new Date(examinations.created_at);
            })
        });

        
        vm.showAdvanced = function (ev, id) {
            $mdDialog.show({
                controller: DialogController,
                templateUrl: 'app/components/patient-details/patient-details-dialog.html',
                parent: angular.element(document.body),
                targetEvent: ev,
                id: id,
                clickOutsideToClose: true
            })
                .then(function (answer) {
                    vm.status = 'You said the information was "' + answer + '".';
                }, function () {
                    vm.status = 'You cancelled the dialog.';
                });
        };

        function DialogController($scope, $mdDialog, $http, id) {
            $scope.examination = [];
            $http.get('doctor/examination-details/'+ id).then(function(data){
               $scope.examination =data.data[0];
               $scope.examination.created_at = new Date($scope.examination.created_at);
               $scope.uploaded = data.data[1];
            });

            // $http.get('/examination_photo/' + $scope.uploaded.filename)
            $scope.hide = function () {
                $mdDialog.hide();
            };

            $scope.cancel = function () {
                $mdDialog.cancel();
            };

            $scope.answer = function (answer) {
                $mdDialog.hide(answer);
            };
        }
    }
})();






