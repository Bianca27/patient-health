<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Patient;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;


class PatientController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['clinics', 'doctors-list', 'examinations', 'patients']);
    }

    public function index()
    {
        $patients = Patient::paginate(5);

        return view('/patients/patients', compact('patients'));
    }

    public function create()
    {
        return view('patients.add');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'firstname' => 'required',
            'lastname' => 'required',
            'cnp' => 'required|unique:patients|size:13',
            'email' => 'required|unique:patients',
            'phone_nr' => 'numeric'
        ]);

        $patient = new Patient;
        $patient->firstname = request('firstname');
        $patient->lastname = request('lastname');
        $patient->address = request('address');
        $patient->cnp = request('cnp');
        $patient->birthday = request('birthday');
        $patient->email = request('email');
        $patient->phone_nr = request('phone_nr');
        $patient->emergency_contact_nr = request('emergency_contact_nr');
        $patient->blood_type = request('blood_type');
        $patient->alergies = request('alergies');
        $password = str_random(8);
        $patient->password = Hash::make($password);
        $patient->save();

        Mail::send('auth.passwords.add-account', ['newPass' => $password, 'user' => $patient->firstname], function ($message) use ($patient) {
            $message->from('office@patient-health.tk', 'Patient Health');
            $message->to($patient->email, '')->subject("Contul dumneavoastra in aplicatia Patient Health a fost creat");
        });

        return redirect('patients/patients');
    }

    public function edit($id)
    {

        $patient = Patient::findOrFail($id);

        return view('patients.edit', compact('patient', $patient));
    }

    public function update($id, Request $request)
    {
        $patient = Patient::findOrFail($id);

        $this->validate($request, [
            'firstname' => 'required',
            'lastname' => 'required',
            'cnp' => 'required',
            'email' => 'required'
        ]);

        $input = $request->all();

        $patient->fill($input)->save();

        return redirect('patients/patients');
    }

}
