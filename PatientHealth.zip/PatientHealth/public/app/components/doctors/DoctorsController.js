(function () {
    'use strict';
    PatientFileApp.controller('DoctorsController', DoctorsController);
    function DoctorsController($rootScope, $scope, $mdDialog, $http) {
        var vm = this;
        vm.getData = function () {
            $http.get('/patient/patient-doctors')
                .then(function(response) {
                    vm.doctors = response.data.doctors;
                    vm.notifications = [];
                    angular.forEach(vm.doctors, function(doctor){
                        if(doctor.is_requested == true) {
                            vm.notifications.push(doctor)
                        }
                    });
                   $scope.notifications = vm.notifications.length;
                   $rootScope.notifications = vm.notifications.length;
                   angular.forEach(vm.doctors, function(doctors){
                       doctors.accepted_request_date = new Date(doctors.accepted_request_date);
                   })
                });
        };

        vm.getData();

        vm.activateDoctor = function(ev, id) {
            var confirm = $mdDialog.confirm()
                .title('Esti sigur?')
                .textContent('Din acest moment acest medic nu mai are acces la datele tale!')
                .targetEvent(ev)
                .ok('Da!')
                .cancel('Nu');
            $mdDialog.show(confirm).then(function(answer) {
                $http.patch('patient/patient-doctors/activate/'+ id);
                vm.getData();
            }, function() {

                doctorsList.all().then(function (data) {
                    vm.doctors = data.data.doctors;
                });

                vm.status = 'Medicul a ramas in lista de medici activi!';
            });
        };

        vm.inactivateDoctor = function(ev, id) {
            var confirm = $mdDialog.confirm()
                .title('Esti sigur?')
                .textContent('Din acest moment acest medic nu mai are acces la datele tale!')
                .targetEvent(ev)
                .ok('Da!')
                .cancel('Nu');
            $mdDialog.show(confirm).then(function(answer) {
                $http.patch('patient/patient-doctors/deactivate/'+ id);
                vm.getData();
            }, function() {
                vm.status = 'Medicul a ramas in lista de medici inactivi!';
            });
        };

        vm.acceptRequest = function(ev, id){
            var confirm = $mdDialog.confirm()
                .title('Esti sigur?')
                .textContent('Din acest moment, acest medic are acces la datele tale!')
                .targetEvent(ev)
                .ok('Da!')
                .cancel('Nu');
            $mdDialog.show(confirm).then(function(answer) {
                $http.patch('patient/patient-doctors/accept/'+ id);
                vm.getData();
            }, function() {
                vm.status = 'Medicul a ramas in lista de medici inactivi!';
            });
        }
    }
})();
