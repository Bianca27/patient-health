
(function () {
    'use strict';
    PatientFileApp.controller('PatientFileDetailsController', PatientFileDetailsController);
    function PatientFileDetailsController($http, $routeParams) {
        var vm = this;
        $http.get('patient/details/' + $routeParams.id).then(function(data){
            vm.examination = data.data;
            vm.examination.created_at = new Date(vm.examination.created_at);
        })
        $http.get('patient/files/' + $routeParams.id).then(function(data){
            vm.uploaded = data.data;

        })
    }
})();
