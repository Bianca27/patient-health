@extends('layouts.app')

@section('content')
    <div class="container">
        <a style="text-decoration: none; color: white;" class="btn btn-primary pull-right" href="{{ url('/clinics/add') }}">Adauga</a>

            <div class="container">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Clinica</th>
                            <th>Adresa</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($clinics as $clinic)
                         <tr>
                            <td>{{$clinic->name}}</td>
                            <td>{{$clinic->address}}</td>
                             <td>
                                 <a href="{{ url('clinics/edit', $clinic->id) }}" class="btn" style="background-color:#27BEC4; color:white;">Editeaza clinica</a>
                             </td>
                        </tr>
                    @endforeach

                    </tbody>
                    <td colspan="2">
                        <div class="pagination">{!! str_replace('/?', '?', $clinics->render()) !!}</div>
                    </td>
                </table>
            </div>
        </div>
    </div>
@endsection
