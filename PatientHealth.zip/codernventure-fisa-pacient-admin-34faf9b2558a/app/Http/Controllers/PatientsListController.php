<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use App\Patient;
use App\Doctor;
use App\Examination;
use App\File;
use App\Weight;
use Carbon\Carbon;
use App\Cholesterol;
use Illuminate\Support\Facades\Storage;
use Response;



class PatientsListController extends Controller
{
    public function __construct()
    {
        Auth::shouldUse('doctor');
        $this->middleware('jwt.auth');
    }

    public function index()
    {
        $id = Auth::user()->id;

        $patients = Doctor::with('patients')->find($id);

//        return view('doctor/patients-list', compact('patients', $patients));

        return Response::json($patients);
    }

    public function getPatientDetails($id)
    {
        $patient = Patient::find($id);

        return Response::json($patient);
    }

    public function show($id)
    {
        $examinations = Examination::with('clinic', 'doctor', 'patient')->where('patient_id', '=', $id)->orderBy('created_at', 'desc')->get();

        return Response::json($examinations);
    }

    public function examination($id)
    {
        $examination = Examination::with('clinic', 'doctor')->findOrFail($id);

        $uploaded = File::where('examination_id', $id)->get();

        return Response::json([$examination, $uploaded]);
    }



    public function getWeightEvolution($id){

        $weight = Weight::where('patient_id', $id)->get();

        return Response::json($weight);
    }

    public function getCholesterolEvolution($id){

        $cholesterol = Cholesterol::where('patient_id', $id)->get();

        return Response::json($cholesterol);
    }
    public function addCholesterol($id)
    {
        $this->validate(request(), [
            'cholesterol_value' => 'required',
            'added_at' => 'required'

        ]);

        $carbon = new Carbon(request('added_at'));
        $dateToCorrectTimezone =  $carbon->addHour(3);

        Cholesterol::create([
            'cholesterol_value' => request('cholesterol_value'),
            'patient_id' => $id,
            'added_at' => $dateToCorrectTimezone
        ]);

        return Response::json(array('success' => true));

    }

    public function addWeight($id)
    {
        $this->validate(request(), [
            'weight_value' => 'required',
            'added_at' => 'required'
        ]);

        $carbon = new Carbon(request('added_at'));
        $dateToCorrectTimezone =  $carbon->addHour(3);

        Weight::create([
            'weight_value' => request('weight_value'),
            'patient_id' => $id,
            'added_at' => $dateToCorrectTimezone
        ]);

        return Response::json(array('success' => true));

    }
}
