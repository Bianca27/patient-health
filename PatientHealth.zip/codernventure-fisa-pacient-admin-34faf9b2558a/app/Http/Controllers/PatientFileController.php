<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

use App\Examination;

use App\File;

use Response;

class PatientFileController extends Controller
{
    public function __construct()
    {
        Auth::shouldUse('patient');
        $this->middleware('jwt.auth');
    }

    public function index(Request $request)
    {
        $id = Auth::user()->id;

        $examinations = Examination::with('clinic', 'doctor')->where('patient_id', '=', $id)->orderBy('created_at', 'desc')->get();
        $show = false;
        $keyword = $request->input('keyword');
        if($keyword!=''){
            $show = true;
            $examinations = Examination::with('clinic', 'doctor')->where('patient_id', '=', $id)->orderBy('created_at', 'desc')->search($keyword)->get();
            $keyword = '';
        }

        return Response::json($examinations);
    }

    public function showExamination($id)
    {
        $examination = Examination::with('clinic', 'doctor')->where('id', $id)->get()->first();

        return Response::json($examination);
    }

    public function getUploadedFiles($id)
    {
        $uploaded = File::where('examination_id', $id)->get();

        return Response::json($uploaded);
    }

    public function getFile($id)
    {
        $file = File::where('id', $id)->get()->first();

        return Response::json($file);
    }
}
