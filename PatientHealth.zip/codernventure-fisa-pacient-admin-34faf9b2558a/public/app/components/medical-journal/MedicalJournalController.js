(function () {
    'use strict';
    PatientFileApp.controller('MedicalJournalController', MedicalJournalController);
    function MedicalJournalController($scope) {


    }

})();
