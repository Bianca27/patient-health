(function () {
    'use strict';
    PatientFileApp.service('fileUploadService', fileUploadService);

    function fileUploadService($http, $q) {

        this.uploadFileToUrl = function (file, examinationId,  uploadUrl) {
            //FormData, object of key/value pair for form fields and values
            var fileFormData = new FormData();
            fileFormData.append('file', file);
            fileFormData.append('examinationId', examinationId);

            var deffered = $q.defer();
            $http.post(uploadUrl, fileFormData, {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}

            }).then(function (response) {
                deffered.resolve(response);

            }).catch(function (response) {
                deffered.reject(response);
            });

            return deffered.promise;
        }
    }

})();