<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Patient;
use Response;

use Illuminate\Support\Facades\Input;

class PatientProfileController extends Controller
{
    public function __construct()
    {
        Auth::shouldUse('patient');
        $this->middleware('jwt.auth');
    }


    public function index()
    {
        $id = Auth::user()->id;
        $patient = Patient::find($id);

        return Response::json($patient);
    }

    public function edit($id)
    {
        $patient = Patient::findOrFail($id);

        return view('patient/edit', compact('patient'));
    }

    public function update($id, Request $request)
    {
        $this->validate(request(), [
            'firstname' => 'required',
            'lastname' => 'required',
            'cnp' => 'required',
            'email' => 'required'
        ]);
        $patient = Patient::findOrFail($id);
        $patient->firstname = request('firstname');
        $patient->lastname = request('lastname');
        $patient->cnp = request('cnp');
        $patient->email = request('email');
        $patient->birthday = date('Y-m-d' , strtotime(request('birthday')));
        $patient->phone_nr = request('phone_nr');
        $patient->emergency_contact_nr = request('emergency_contact_nr');
        $patient->blood_type = request('blood_type');
        $patient->alergies = request('alergies');
        $patient->address = request('address');
        $patient->save();

        return Response::json(array('success' => true));

    }

    public function changePassword($id, Request $request){

        $this->validate(request(), [
            'password' => 'required',
        ]);

        $password =  $request->get('password');
        $user = Patient::find($id);
        $patient = Patient::find($user->id);
        $patient->password = bcrypt($password);
        $patient->save();

        return Response::json(array('success' => true));

    }
}
