PatientFileApp.config(function ($routeProvider, $locationProvider, $authProvider) {

    // Satellizer configuration that specifies which API
    // route the JWT should be retrieved from
    $authProvider.loginUrl = '/doctor/login';

    $locationProvider.hashPrefix('');

    $routeProvider.when('/doctors-login', {
        templateUrl: 'app/components/login-doctors/doctors-login.html',
        controller: 'DoctorsLoginController',
        controllerAs: 'doctor'
    });
    $routeProvider.when('/main-dashboard', {
        templateUrl: 'app/components/main-dashboard/main-dashboard.html',
        controller: 'MainDashboardController',
        controllerAs: 'main'
    });
    $routeProvider.when('/doctor-register', {
        templateUrl: 'app/components/doctor-register/doctor-register.html',
        controller: 'AddDoctorController',
        controllerAs: 'addUserDoctor'
    });
    $routeProvider.when('/my-patients', {
        templateUrl: 'app/components/my-patients/my-patients.html',
        controller: 'MyPatientsController',
        controllerAs: 'doctor'
    });

    $routeProvider.when('/all-patients', {
        templateUrl: 'app/components/all-patients/all-patients.html',
        controller: 'AllPatientsController',
        controllerAs: 'allPatients'
    });
    $routeProvider.when('/add-patient', {
        templateUrl: 'app/components/add-patient/add-patient.html',
        controller: 'AddPatientController',
        controllerAs: 'addPatient'
    });

    $routeProvider.when('/add-examination/:id', {
        templateUrl: 'app/components/add-examination/add-examination.html',
        controller: 'AddExaminationController',
        controllerAs: 'addExamination'
    });
    $routeProvider.when('/examination/edit/:id', {
        templateUrl: 'app/components/edit-examination/edit-examination.html',
        controller: 'EditExaminationController',
        controllerAs: 'editExamination'
    });
    $routeProvider.when('/patient-details/:id', {
        templateUrl: 'app/components/patient-details/patient-details.html',
        controller: 'PatientDetailsController',
        controllerAs: 'details'
    });
    $routeProvider.when('/patient-weight-evolution/:id', {
        templateUrl: 'app/components/patient-details/patient-weight-evolution.html',
        controller: 'patientWeightEvolutionController',
        controllerAs: 'evolution'
    });
    $routeProvider.when('/patient-cholesterol-evolution/:id', {
        templateUrl: 'app/components/patient-details/patient-cholesterol-evolution.html',
        controller: 'patientCholesterolEvolutionController',
        controllerAs: 'evolution'

    });

    $routeProvider.when('/doctors-password-recovery', {
        templateUrl: 'app/components/doctors-password-recovery/doctors-password-recovery.html',
        controller: 'DoctorsPasswordRecoveryController',
        controllerAs: 'recover'
    });
    $routeProvider.when('/doctors-change-password', {
        templateUrl: 'app/components/change-password/doctors-change-password.html',
        controller: 'DoctorsChangePasswordController',
        controllerAs: 'change'
    });
    $routeProvider.otherwise({ redirectTo: '/doctors-login' });
});

function loginTokenValidator($location, $q) {
    return {
        responseError: function(rejection) {

            // Instead of checking for a status code of 400 which might be used
            // for other reasons in Laravel, we check for the specific rejection
            // reasons to tell us if we need to redirect to the login state
            var rejectionReasons = ['token_not_provided', 'token_expired', 'token_absent', 'token_invalid'];

            // Loop through each rejection reason and redirect to the login
            // state if one is encountered
            angular.forEach(rejectionReasons, function(value, key) {

                if(rejection.data.error === value) {

                    // If we get a rejection corresponding to one of the reasons
                    // in our array, we know we need to authenticate the user so
                    // we can remove the current user from local storage
                    localStorage.removeItem('user');

                    // Send the user to the auth state so they can login
                    $location.path('/doctors-login')
                }
            });

            // return rejection;
            //This helps us to get back the error
            return $q.reject(rejection);
        }
    }
}

PatientFileApp.factory('loginTokenValidator', loginTokenValidator)
    .config(function($httpProvider) {
        $httpProvider.interceptors.push('loginTokenValidator');
    });


PatientFileApp.run(function($rootScope, $location, $http, loginService) {

    // $stateChangeStart is fired whenever the state changes. We can use some parameters
    // such as toState to hook into details about the state as it is changing
    $rootScope.$on('$routeChangeStart', function() {

        // Grab the user from local storage and parse it to an object
        var user = JSON.parse(localStorage.getItem('user'));

        // If there is any user data in local storage then the user is quite
        // likely authenticated. If their token is expired, or if they are
        // otherwise not actually authenticated, they will be redirected to
        // the auth state because of the rejected request anyway


        if ($location.path() !== "/doctors-password-recovery" && $location.path() !== "/doctor-register") {
            if(user) {

                // The user's authenticated state gets flipped to
                // true so we can now show parts of the UI that rely
                // on the user being logged in
                $rootScope.authenticated = true;

                // Putting the user's data on $rootScope allows
                // us to access it anywhere across the app. Here
                // we are grabbing what is in local storage
                $rootScope.currentUser = user;

                // If the user is logged in and we hit the login route we don't need
                // to stay there and can send the user to the dashboard
                if($location.path() === "/doctors-login") {
                    $location.path('/main-dashboard');
                }
            } else {
                //We set it to false so we can hide the left menu
                $rootScope.authenticated = false;
                $location.path('/doctors-login');
            }
        }

    });
});
