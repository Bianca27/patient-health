<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Doctor extends Authenticatable
{
    use Notifiable;

    protected $guard = 'doctor';

    protected $appends = ['is_active', 'is_requested'];

    protected $hidden = [
        'password', 'remember_token', 'email'
    ];

    public function examination()
    {
        return $this->hasMany(Examination::class);
    }

    public function clinic()
    {
        return $this->belongsTo(Clinic::class);
    }

    public function patients()
    {
        return $this->belongsToMany(Patient::class, 'doctor_patients')->withPivot('active')->wherePivot('active', '=' ,1)->withTimestamps();
    }

    public function allPatients()
    {
        return $this->belongsToMany(Patient::class, 'doctor_patients')->withPivot('active')->wherePivot('active', '=' ,0);
    }

    public function doctorRequests()
    {
        return $this->belongsToMany(Patient::class, 'doctor_patients')->withPivot('access_requested')->wherePivot('access_requested', '=' ,1);
    }

    public function getIsActiveAttribute() {

        if(isset($this->pivot->active)) {
            if($this->pivot->active == 1) {
                 return true;
            } else {
                if(isset($this->pivot->access_requested)) {
                    if($this->pivot->active == 0 && $this->pivot->access_requested == 0){
                        return false;
                    }
                }
            }

        }
    }

    public function getIsRequestedAttribute(){

        if(isset($this->pivot->access_requested) && ($this->pivot->access_requested == 1)){
            return true;
        }
        return false;
    }

    protected $fillable = ['name', 'specialization', 'clinic_id', 'email', 'password', 'phone_nr'];
}
