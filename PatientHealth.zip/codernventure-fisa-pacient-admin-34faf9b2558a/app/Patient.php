<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Auth;

class Patient extends Authenticatable
{
    use Notifiable;

    protected $guard = 'patient';

    protected $appends = ['is_patient', 'access_is_requested'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'firstname', 'lastname', 'email', 'birthday', 'password', 'cnp', 'sex', 'address', 'phone_nr', 'emergency_contact_nr', 'blood_type', 'alergies'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token'
    ];

    public function examination()
    {
        return $this->hasMany(Examination::class);
    }

    public function weight()
    {
        return $this->hasMany(Weight::class);
    }

    public function doctors()
    {
        return $this->belongsToMany(Doctor::class,'doctor_patients')->withPivot('active', 'access_requested', 'accepted_request_date');
    }

    public function activeDoctors()
    {
        return $this->belongsToMany(Doctor::class,'doctor_patients')->withPivot('active')->wherePivot('active', 1);
    }

    public function inactiveDoctors()
    {
        return $this->belongsToMany(Doctor::class, 'doctor_patients')->withPivot('active')->wherePivot('active', 0);
    }

    public function requests()
    {
        return $this->belongsToMany(Doctor::class, 'doctor_patients')->withPivot('access_requested')->wherePivot('access_requested', 1);
    }

    public function getDoctors()
    {
        return $this->belongsToMany(Doctor::class, 'doctor_patients')->wherePivot('active', 1);
    }

    public function scopeSearch($query, $keyword){
        return $query->where('cnp', 'like', '%' .$keyword. '%');
    }

    function getIsPatientAttribute() {

        if(isset(Auth::user()->id)){
            $id = Auth::user()->id;

            foreach ($this->getDoctors as $doctor){
                if ($id == $doctor->id){
                    return true;
                }
            }
        }

        return false;
    }

    function getAccessIsRequestedAttribute(){

        if(isset(Auth::user()->id)){
            $id = Auth::user()->id;

            foreach ($this->requests as $request){
                if ($id == $request->id){
                    return true;
                }
            }
        }
        return false;
    }
}