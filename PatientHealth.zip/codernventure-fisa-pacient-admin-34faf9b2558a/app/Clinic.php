<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Clinic extends Model
{
    public function doctor()
    {
        return $this->hasMany(Doctor::class);
    }

    public function examination()
    {
        return $this->hasMany(Examination::class);
    }


    protected $fillable = ['name', 'address'];
}
