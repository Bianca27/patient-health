@extends('layouts.app')

@section('content')
    <div class="container">
        <a style="text-decoration: none; color: white;" class="btn btn-primary pull-right" href="{{ url('/patients/add') }}">Adauga</a>

        <div class="container adjust-width">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Nume</th>
                    <th>Prenume</th>
                    <th>CNP</th>
                    <th>Adresa</th>
                    <th>Data nasterii</th>
                    <th>Email</th>
                    <th>Nr de telefon</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                @foreach($patients as $patient)
                    <tr>
                        <td>{{$patient->lastname}}</td>
                        <td>{{$patient->firstname}}</td>
                        <td>{{$patient->cnp}}</td>
                        <td>{{$patient->address}}</td>
                        <td>{{ date('d-m-Y', strtotime($patient->birthday))}}</td>
                        <td>{{$patient->email}}</td>
                        <td>{{$patient->phone_nr}}</td>
                        <td>
                            <a href="{{ url('patients/edit', $patient->id) }}" class="btn" style="background-color:#27BEC4; color:white;">Editeaza pacient</a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
                <td colspan="2">
                    <div class="pagination">{!! str_replace('/?', '?', $patients->render()) !!}</div>
                </td>
            </table>
        </div>
    </div>
@endsection