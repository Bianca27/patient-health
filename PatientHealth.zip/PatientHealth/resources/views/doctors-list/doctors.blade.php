@extends('layouts.app')

@section('content')
    <div class="container">
        <a style="text-decoration: none; color: white;" class="btn btn-primary pull-right" href="{{ url('doctors-list/add') }}">Adauga</a>

        <div class="container">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Nume medic</th>
                    <th>Specializare</th>
                    <th>Email</th>
                    <th>Numar de telefon</th>
                    <th>Clinica</th>
                </tr>
                </thead>
                <tbody>
                @foreach($doctors as $doctor)
                    <tr>
                        <td>{{$doctor->name}}</td>
                        <td>{{$doctor->specialization}}</td>
                        <td>{{$doctor->email}}</td>
                        <td>{{$doctor->phone_nr}}</td>
                        <td>{{$doctor->clinic->name}}</td>
                        <td>
                            <a href="{{ url('doctors-list/edit', $doctor->id) }}" class="btn" style="background-color:#27BEC4; color:white;">Editeaza medic</a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
                <td colspan="6" >
                    <div style="text-align: center;">
                    {!! str_replace('/?', '?', $doctors->render()) !!}
                    </div>
                </td>
            </table>
        </div>
    </div>



@endsection