@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">Editare medic</div>
            <div class="panel-body">
                {!! Form::model($doctor, [
                   'method' => 'PATCH',
                   'url' => ['doctors-list/update', $doctor->id]
               ]) !!}

                <div class="form-group">
                    {!! Form::label('name', 'Name:', ['class' => 'control-label']) !!}
                    {!! Form::text('name', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('specialization', 'Specialization:', ['class' => 'control-label']) !!}
                    {!! Form::text('specialization', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('email', 'Email:', ['class' => 'control-label']) !!}
                    {!! Form::text('email', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('phone_nr', 'Numar de telefon:', ['class' => 'control-label']) !!}
                    {!! Form::text('phone_nr', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group">
                    {!! Form::label('clinics', 'Clinics:', ['class' => 'control-label']) !!}
                    {!! Form::select('clinic', $clinics, null, ['class' => 'form-control']) !!}
                </div>

                <a href="doctors-list/doctors">Inapoi</a>

                {!! Form::submit('Editeaza medic', ['class' => 'btn blue-button pull-right']) !!}

                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection