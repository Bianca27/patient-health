(function () {
    'use strict';
    PatientFileApp.controller('AddPatientController', AddPatientController);
    function AddPatientController($http, $mdDialog, $location) {
        var vm = this;
        vm.back = function () {
            window.history.back();
        };
        vm.addPatient = function (pacient, ev) {

            var data = {
                firstname: vm.firstname,
                lastname: vm.lastname,
                cnp: vm.cnp,
                birthday: vm.birthday,
                phone_nr: vm.phone_nr,
                emergency_contact_nr: vm.emergency_contact_nr,
                blood_type: vm.blood_type,
                alergies: vm.alergies,
                address: vm.address,
                email: vm.email,
                password: vm.password
            };

            $http.post('doctor/add-patient', data)
            .then(function onSuccess(response) {
                // Handle success
                var data = response.data;
                var status = response.status;

                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('Felicitari!')
                        .textContent('Pacientul a fost adaugat cu succes!')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {
                    $location.path('/all-patients');
                });


            }).catch(function onError(response) {
                // Handle error
               vm.data = response.data;
               if(vm.data.cnp){
                   vm.error = vm.data.cnp[0];
               }
               if(vm.data.email){
                   vm.error = vm.data.email[0];
               }
               if(vm.data.firstname || vm.data.lastname || vm.data.phone_nr){
                   vm.error = 'Va rugam completati toate campurile obligatorii'
               }
                var status = response.status;
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('A avut loc o eroare!')
                        .textContent(vm.error)
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {

                });
            });

        };
    }
})();
