(function () {
    'use strict';
    PatientFileApp.controller('PasswordRecoveryController', PasswordRecoveryController);
    function PasswordRecoveryController($http, $mdDialog, $location) {
        var vm = this;
        vm.recoverPassword = function(email, ev){
            var data = {
                email: vm.email
            };

            $http.post('patient/reset-password', data)
                .then(function onSuccess(response){
                        var data = response.data;
                        var status = response.status;

                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('Parola a fost resetata!')
                            .textContent('Un email cu o noua parola a fost trimis!')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('OK!')
                            .targetEvent(ev)
                    ).then(function() {
                        $location.path('/login');
                    });
                }).catch(function onError(response){
                vm.data = response.data;
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('A avut loc o eroare!')
                        .textContent('')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {

                });

            })
        };
    };

})();
