(function () {
    'use strict';
    PatientFileApp.controller('DoctorsChangePasswordController', DoctorsChangePasswordController);
    function DoctorsChangePasswordController($rootScope, $http, $mdDialog,$location ) {
        var vm = this;
        vm.back = function () {
            window.history.back();
        };
        vm.changePassword = function(password, ev){
            var data = {
                password: vm.password
            }

            $http.post('doctor/change-password/' + $rootScope.currentUser.id, data)
                .then(function onSuccess(response){
                    var data = response.data;
                    var status = response.status;
                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('Felicitari!')
                            .textContent('Parola a fost schimbata cu success!')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('OK!')
                            .targetEvent(ev)
                    ).then(function() {
                        $location.path('/dashboard');
                    });


                }).catch(function onError(response) {
                // Handle error
                var data = response.data;
                console.log(data);
                var status = response.status;
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('A avut loc o eroare!')
                        .textContent('Campurile email si parola sunt obligatorii')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {

                });
            });

        };
    };

})();

