(function () {
    'use strict';
    PatientFileApp.controller('CholesterolChartController', CholesterolChartController);
    function CholesterolChartController($rootScope, $http) {
        var vm = this;
        vm.getData = function(){

           vm.dataCholesterol = [];

           $http.get('/patient/cholesterol-evolution')
               .then(function(response) {
                   vm.cholesterol = response.data;
                   angular.forEach(vm.cholesterol, function(cholesterol){
                       vm.dataCholesterol.push(
                           {
                               "label": cholesterol.added_at,
                               "value": cholesterol.cholesterol_value
                           }
                       )
                   });
               });

           return vm.dataCholesterol;
       };

        vm.drawChart = function() {

            vm.dataSource = {
                "chart": {
                    "caption": "Evolutie colesterol",
                    "subCaption": $rootScope.currentUser.firstname,
                    "xAxisName": "Data",
                    "yAxisName": "Cholesterol (mg/dl)",
                    "numberPrefix": "mg/dl",
                    "paletteColors": "#27BEC4",
                    "bgColor": "#ffffff",
                    "borderAlpha": "20",
                    "canvasBorderAlpha": "0",
                    "usePlotGradientColor": "0",
                    "plotBorderAlpha": "10",
                    "placevaluesInside": "1",
                    "rotatevalues": "1",
                    "valueFontColor": "#ffffff",
                    "showXAxisLine": "1",
                    "xAxisLineColor": "#999999",
                    "divlineColor": "#999999",
                    "divLineDashed": "1",
                    "showAlternateHGridColor": "0",
                    "subcaptionFontBold": "0",
                    "subcaptionFontSize": "14"
                },

                "data": vm.getData()
            };
        };

        vm.drawChart();
    }
})();