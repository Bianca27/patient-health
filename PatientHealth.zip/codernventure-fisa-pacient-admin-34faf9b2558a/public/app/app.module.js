var PatientFileApp = angular.module('PatientFileApp', [ 'ngResource', 'ngRoute', 'ngMaterial','ngMessages', 'xeditable',  'ng-fusioncharts', 'satellizer',  'mdCollectionPagination']);

// PatientFileApp.config(['$qProvider', function ($qProvider) {
//     $qProvider.errorOnUnhandledRejections(false);
// }]);



