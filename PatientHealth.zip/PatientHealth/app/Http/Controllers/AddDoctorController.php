<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Doctor;

use App\Clinic;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class AddDoctorController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['clinics', 'doctors-list', 'examinations']);
    }
    public function index(){

        $clinics = Clinic::orderBy('name')->get()->pluck('name', 'id');

        return view('/doctors-list/add', compact('clinics'));
    }

    public function store()
    {
        $this->validate(request(), [
            'name' => 'required',
            'specialization' => 'required',
            'email' => 'required|unique:doctors',
            'phone_nr' => 'required|numeric',
        ]);

        $doctor = new Doctor;
        $doctor->name = request('name');
        $doctor->specialization = request('specialization');
        $doctor->email = request('email');
        $doctor->clinic_id =  request('clinic');
        $doctor->phone_nr =  request('phone_nr');
        $password = str_random(8);
        $doctor->password = Hash::make($password);
        $doctor->save();

        Mail::send('auth.passwords.add-account', ['newPass' => $password, 'user' => $doctor->name], function ($message) use ($doctor) {
            $message->from('office@patient-health.tk', 'Patient Health');
            $message->to($doctor->email, '')->subject("Contul dumneavoastra in aplicatia Patient Health a fost creat");
        });

        return redirect('/doctors-list/doctors');
    }
}
