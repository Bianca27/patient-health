(function () {
    'use strict';
    PatientFileApp.controller('MyPatientsController', MyPatientsController);
    function MyPatientsController(patientList) {
        var vm = this;
        vm.patients = [];
        patientList.get().then(function (data) {
            vm.patients = data.data.patients;
        });
        vm.search = '';
    };

})();
