@extends('layouts.app')

@section('content')
<div class="container">
    <div class="panel panel-default">
        <div class="panel-heading">Adaugare clinica</div>
        <div class="panel-body">
            @if($errors->any())
                <div class="alert alert-danger">
                    @foreach($errors->all() as $error)
                        <p>{{ $error }}</p>
                    @endforeach
                </div>
            @endif

            {!! Form::open([
             'method' => 'POST',
             'url' => '/clinics/add'
           ]) !!}

            <div class="form-group">
                {!! Form::label('name', 'Nume clinica:', ['class' => 'control-label']) !!}
                {!! Form::text('name', null, ['class' => 'form-control']) !!}
            </div>

            <div class="form-group">
                {!! Form::label('address', 'Adresa:', ['class' => 'control-label']) !!}
                {!! Form::textarea('address', null, ['class' => 'form-control']) !!}
            </div>
                <a href="{{ URL::previous() }}" class="btn btn primary blue">Inapoi la lista clinici</a>
                {!! Form::submit('Adauga clinica', ['class' => 'btn blue-button pull-right']) !!}
            {!! Form::close() !!}

        </div>
    </div>
</div>
@endsection