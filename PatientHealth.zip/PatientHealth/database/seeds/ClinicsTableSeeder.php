<?php

use Illuminate\Database\Seeder;

class ClinicsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $clinics = [
            [
                'name'=>'Sf Constantin',
                'address' => 'Strada Mihai Viteazu nr. 6'

            ],
            [
                'name'=>'Regina Maria',
                'address' => 'Strada Turnului nr. 5'
            ],
            [
                'name'=>'MedLife',
                'address' => 'Strada Principala nr. 10'
            ],
            [
                'name'=>'Medica',
                'address' => 'Strada Veche nr. 23'
            ],
        ];

        foreach($clinics as $clinic){
            DB::table('clinics')->insert([$clinic]);
        }

    }
}
