
(function () {
    'use strict';
    PatientFileApp.controller('EditExaminationController', EditExaminationController);
    function EditExaminationController($http, $routeParams, $location, $mdDialog, $scope ,fileUploadService) {
        var vm = this;
        vm.back = function () {
            window.history.back();
        };
        $http.get('doctor/examination-details/'+ $routeParams.id).then(function(data){
            vm.examination =data.data[0];
            vm.uploaded = data.data[1];
        });

        vm.editExamination = function (examination, ev) {
            var data = {
                title: vm.examination.title,
                simptoms: vm.examination.simptoms,
                diagnosis: vm.examination.diagnosis,
                treatment: vm.examination.treatment,

            };

            $http.post('doctor/edit-examination/edit/' + $routeParams.id , data)
                .then(function onSuccess(response) {
                    var status = response.status;
                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('Felicitari!')
                            .textContent('Consultatia a fost editata cu succes!')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('OK!')
                            .targetEvent(ev)
                    ).then(function() {
                        //$location.path('/patient-details/' + $routeParams.id);
                    });

                }).catch(function onError(response) {
                var message = 'Toate campurile sunt obligatorii!';

                if(response.status === 404) {
                    message = 'Pacientul nu exista';
                }
                if(response.status === 403) {
                    message = 'Pacientul nu este in lista autorizata';
                }
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('A avut loc o eroare!')
                        .textContent(message)
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {
                });
            });
        }

        vm.uploadFile = function (patientId, ev) {
            var file = $scope.myFile;
            if(file['size'] > 2097152) {
                $scope.error = 'Fisierul depaseste dimensiunea maxima admisa!';
                return;
            }
            var examinationId = vm.examination.id;

            var uploadUrl = "doctor/examination/upload",
                promise = fileUploadService.uploadFileToUrl(file, examinationId,  uploadUrl);

            promise.then(function onSuccess(response) {
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('Felicitari!')
                        .textContent('Fisierul a fost adaugat cu success!')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {
                    $location.path('/patient-details/' + patientId);
                });
            }).catch(function onError(response) {
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('A avut loc o eroare!')
                        .textContent('Incearca din nou!')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {

                });
                $scope.serverResponse = response;
            });
        };

    }

})();
