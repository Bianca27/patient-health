<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Patient;
use App\Doctor;
use App\DoctorPatient;
use Illuminate\Support\Facades\Auth;
use Response;

class PatientDoctorsController extends Controller
{
    public function __construct()
    {
        Auth::shouldUse('patient');
        $this->middleware('jwt.auth');
    }


    public function index()
    {
        $id = Auth::user()->id;

        $doctors = Patient::with('doctors')->find($id);

        $doctorRequests = Patient::with('requests')->find($id);

        return Response::json($doctors);

    }

    public function getAccessRequests()
    {
        $id = Auth::user()->id;
        $requests = DoctorPatient::where('patient_id', $id)->where('access_requested', 1)->get()->count();

        return Response::json($requests);
    }

    public function deactivate($id)
    {
        $userId = Auth::user()->id;

        $activeDoctors = Patient::with('activeDoctors')->find($userId);

        $activeDoctors->activeDoctors->find($id)->pivot->update(['active' => 0]);

        return ;

    }

    public function activate($id)
    {
        $userId = Auth::user()->id;

        $inactiveDoctors = Patient::with('inactiveDoctors')->find($userId);

        $inactiveDoctors->inactiveDoctors->find($id)->pivot->update(['active' => 1]);

        return;

    }

    public function accept($id)
    {
        $userId = Auth::user()->id;

        $doctorRequests = Patient::with('requests')->find($userId);

        $doctorRequests->requests->find($id)->pivot->update(['access_requested' => 0]);

        $doctorRequests->requests->find($id)->pivot->update(['active' => 1]);

        $doctorRequests->requests->find($id)->pivot->update(['accepted_request_date' => date('Y-m-d H:i:s')]);


        return;
    }

}
