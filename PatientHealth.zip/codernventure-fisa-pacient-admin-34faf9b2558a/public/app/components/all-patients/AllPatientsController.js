(function () {
    'use strict';
    PatientFileApp.controller('AllPatientsController', AllPatientsController);
    function AllPatientsController($http, $mdDialog) {
        var vm = this;
        vm.patients = [];
        vm.getData = function () {
            $http.get('/doctor/all-patients')
                .then(function(response) {
                    vm.patients = response.data;
                });
        };
        vm.getData();
        vm.search = '';

        vm.showConfirm = function(ev, id) {

            var confirm = $mdDialog.confirm()
                .title('Cere acces la istoricul acestui pacient')
                .textContent('Din momentul acceptarii acestei cereri veti avea acces la istoricul acestui pacient.')
                .targetEvent(ev)
                .ok('Cere acces')
                .cancel('Nu, multumesc!');

            $mdDialog.show(confirm).then(function() {
                $http.post('doctor/all-patients/'+ id);
                vm.getData();

                vm.status = 'Aveti acces la istoricul acestui pacient.';
            }, function() {
                vm.status = 'Nu aveti acces la istoricul acestui pacient.';
            });
        };
    }

})();
