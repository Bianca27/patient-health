(function () {
    'use strict';
    PatientFileApp.factory('examinationService', examinationService);
    function examinationService($http) {

        var examinations = $http.get('/patient/patient-file');

        return {
            all: function () {
                return examinations;

            },

        }

    }
})();