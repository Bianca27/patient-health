(function () {
    'use strict';
    PatientFileApp.factory('patientList', patientList);
    function patientList($http) {

        var patients = $http.get('/doctor/patients-list');

        return {
            get: function () {
                return patients;
            }
        }

    }
})();