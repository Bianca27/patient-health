(function () {
    'use strict';
    PatientFileApp.controller('EditProfileController', EditProfileController);
    function EditProfileController($http, $location, $mdDialog, userInfo) {
        var vm = this;

        userInfo.get().then(function (data) {
            vm.userInfo = data.data;
            vm.userInfo.birthday = new Date(vm.userInfo.birthday);

        });

        vm.updateInfo = function(id, ev){

            var data = {
                firstname: vm.userInfo.firstname,
                lastname: vm.userInfo.lastname,
                cnp: vm.userInfo.cnp,
                email: vm.userInfo.email,
                birthday: vm.userInfo.birthday,
                phone_nr: vm.userInfo.phone_nr,
                emergency_contact_nr: vm.userInfo.emergency_contact_nr,
                blood_type: vm.userInfo.blood_type,
                alergies: vm.userInfo.alergies,
                address: vm.userInfo.address
            };

            $http.post('/patient/update/'+ id, data)
                .then(function onSuccess(response) {
                    var data = response.status;
                    var status = response.data;

                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('Felicitari!')
                        .textContent('Profilul a fost editat cu success!')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {
                    $location.path('/profile');

                });
            }).catch(function onError(response) {
                // Handle error
                var data = response.data;
                var status = response.status;
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('A avut loc o eroare!')
                        .textContent('Incearca din nou!')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {

                });
            });


        }
    }

})();

