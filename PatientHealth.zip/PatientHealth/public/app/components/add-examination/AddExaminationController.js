(function () {
    'use strict';
    PatientFileApp.controller('AddExaminationController', AddExaminationController);
    function AddExaminationController($http, $routeParams, $location, $mdDialog, $scope ,fileUploadService) {
        var vm = this;
        vm.back = function () {
            window.history.back();
        };
        vm.addExamination = function (examination, ev) {
            var data = {
                title: vm.title,
                simptoms: vm.simptoms,
                diagnosis: vm.diagnosis,
                treatment: vm.treatment,

            };
            $http.post('doctor/patients-list/add-examination/' + $routeParams.id , data)
                .then(function onSuccess(response) {
                    var data = response.data;
                    $scope.examinationId = data.examinationId;
                    var status = response.status;
                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('Felicitari!')
                            .textContent('Consultatia a fost adaugata cu succes!')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('OK!')
                            .targetEvent(ev)
                    ).then(function() {
                        //$location.path('/patient-details/' + $routeParams.id);
                        $scope.saved = true;
                    });

                }).catch(function onError(response) {
                var message = 'Toate campurile sunt obligatorii!';

                if(response.status === 404) {
                    message = 'Pacientul nu exista';
                }
                if(response.status === 403) {
                    message = 'Pacientul nu este in lista autorizata';
                }
                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('A avut loc o eroare!')
                            .textContent(message)
                            .ariaLabel('Alert Dialog Demo')
                            .ok('OK!')
                            .targetEvent(ev)
                    ).then(function() {
                });
            });
        }

        vm.uploadFile = function (ev) {
            var file = $scope.myFile;
            if(file['size'] > 2097152) {
                $scope.error = 'Fisierul depaseste dimensiunea maxima admisa!';
                return;
            }
            var examinationId = $scope.examinationId;

            var uploadUrl = "doctor/examination/upload",
                promise = fileUploadService.uploadFileToUrl(file, examinationId,  uploadUrl);

            promise.then(function onSuccess(response) {
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('Felicitari!')
                        .textContent('Fisierul a fost adaugat cu success!')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {
                    $location.path('/patient-details/' + $routeParams.id);
                    $scope.saved = true;
                });
            }).catch(function onError(response) {
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('A avut loc o eroare!')
                        .textContent('Incearca din nou!')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('OK!')
                        .targetEvent(ev)
                ).then(function() {

                });
                $scope.serverResponse = response;
            });
        };

    }

})();
