(function () {
    'use strict';
    PatientFileApp.factory('examinationsService', examinationsService);
    function examinationsService($http, $routeParams) {
        var info = $http.get('doctor/patients-list/' + $routeParams.id);
        return {
            get: function () {
                return info;
            }
        }

    }
})();